'''
Created on 2012-01-24

@author: Andrew Roth
'''
genotypes = ['AA', 'AB', 'BB']

joint_genotypes = ['AA_AA',
                   'AA_AB',
                   'AA_BB',
                   'AB_AA',
                   'AB_AB',
                   'AB_BB',
                   'BB_AA',
                   'BB_AB',
                   'BB_BB']
